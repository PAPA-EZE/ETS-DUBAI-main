@extends('layouts.app')

@section('title', 'Rapport des Stocks')
@section('page-title', 'Rapport des Stocks')

@section('content')
  <div class="fade-in">
    <x-breadcrumb :items="[
      ['label' => 'Rapports', 'url' => route('rapports.index')],
      ['label' => 'Stocks', 'url' => null],
    ]" />

    <div class="mb-6">
      <h2 class="text-2xl font-bold text-gray-900">État des Stocks</h2>
      <p class="text-gray-600 mt-1">Vue d'ensemble et valorisation des stocks actuels</p>
    </div>

    <!-- Statistiques globales -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      <div class="card p-6 bg-primary-50 border-l-4 border-primary-500">
        <p class="text-sm font-medium text-primary-900">Total Produits</p>
        <p class="text-3xl font-bold text-primary-600 mt-2">{{ $stats['total_produits'] }}</p>
        <p class="text-sm text-primary-700 mt-1">produits actifs</p>
      </div>

      <div class="card p-6 bg-danger-50 border-l-4 border-danger-500">
        <p class="text-sm font-medium text-danger-900">En Rupture</p>
        <p class="text-3xl font-bold text-danger-600 mt-2">{{ $stats['en_rupture'] }}</p>
        <p class="text-sm text-danger-700 mt-1">produits</p>
      </div>

      <div class="card p-6 bg-warning-50 border-l-4 border-warning-500">
        <p class="text-sm font-medium text-warning-900">Stock Faible</p>
        <p class="text-3xl font-bold text-warning-600 mt-2">{{ $stats['stock_faible'] }}</p>
        <p class="text-sm text-warning-700 mt-1">alertes</p>
      </div>

      <div class="card p-6 bg-success-50 border-l-4 border-success-500">
        <p class="text-sm font-medium text-success-900">Valeur du Stock</p>
        <p class="text-3xl font-bold text-success-600 mt-2">{{ number_format($stats['valeur_stock'], 0, ',', ' ') }}</p>
        <p class="text-sm text-success-700 mt-1">FCFA (prix d'achat)</p>
      </div>
    </div>

    <!-- Stock par catégorie -->
    @if($parCategorie->count() > 0)
      <div class="card mb-6">
        <div class="px-6 py-4 border-b border-gray-200">
          <h3 class="text-lg font-semibold text-gray-900">Stock par Catégorie</h3>
        </div>
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Catégorie</th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Nb Produits</th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Quantité Totale</th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Valeur</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              @foreach($parCategorie as $categorie => $stats)
                <tr>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span class="text-sm font-medium text-gray-900">{{ $categorie ?: 'Non catégorisé' }}</span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                    {{ $stats['nombre'] }}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                    {{ number_format($stats['quantite_totale'], 0, ',', ' ') }}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-gray-900">
                    {{ number_format($stats['valeur'], 0, ',', ' ') }} FCFA
                  </td>
                </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    @endif

    <!-- Liste détaillée des produits -->
    <div class="card">
      <div class="px-6 py-4 border-b border-gray-200">
        <h3 class="text-lg font-semibold text-gray-900">Détail par Produit</h3>
      </div>
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produit</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fournisseur</th>
              <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Stock</th>
              <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Prix Achat</th>
              <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Valeur</th>
              <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Statut</th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            @foreach($produits as $produit)
              <tr class="hover:bg-gray-50">
                <td class="px-6 py-4">
                  <div class="text-sm font-medium text-gray-900">{{ $produit->nom }}</div>
                  <div class="text-xs text-gray-500">{{ $produit->categorie?->nom }}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {{ $produit->fournisseur?->nom }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right">
                  <span
                    class="text-sm font-medium {{ $produit->stock_actuel <= 0 ? 'text-danger-600' : ($produit->stock_actuel <= $produit->stock_minimum ? 'text-warning-600' : 'text-gray-900') }}">
                    {{ number_format($produit->stock_actuel, 0, ',', ' ') }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                  {{ number_format($produit->prix_achat, 0, ',', ' ') }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-gray-900">
                  {{ number_format($produit->stock_actuel * $produit->prix_achat, 0, ',', ' ') }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-center">
                  @if($produit->stock_actuel <= 0)
                    <span
                      class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-danger-100 text-danger-800">
                      Rupture
                    </span>
                  @elseif($produit->stock_actuel <= $produit->stock_minimum)
                    <span
                      class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-warning-100 text-warning-800">
                      Faible
                    </span>
                  @else
                    <span
                      class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success-100 text-success-800">
                      OK
                    </span>
                  @endif
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
@endsection