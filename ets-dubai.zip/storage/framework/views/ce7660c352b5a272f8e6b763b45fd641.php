<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ticket <?php echo e($vente->numero_vente); ?></title>
  <style>
    @media print {
      @page {
        margin: 0;
      }

      body {
        margin: 0.5cm;
      }
    }

    body {
      font-family: 'Courier New', monospace;
      font-size: 12px;
      max-width: 80mm;
      margin: 0 auto;
      padding: 10px;
    }

    .ticket-header {
      text-align: center;
      border-bottom: 2px dashed #000;
      padding-bottom: 10px;
      margin-bottom: 10px;
    }

    .ticket-header h1 {
      margin: 0;
      font-size: 18px;
      font-weight: bold;
    }

    .ticket-header p {
      margin: 2px 0;
      font-size: 10px;
    }

    .ticket-info {
      margin-bottom: 10px;
      font-size: 11px;
    }

    .ticket-info div {
      display: flex;
      justify-content: space-between;
      margin: 3px 0;
    }

    .items-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 10px;
    }

    .items-table th {
      text-align: left;
      border-bottom: 1px solid #000;
      padding: 3px 0;
      font-size: 10px;
    }

    .items-table td {
      padding: 3px 0;
      font-size: 11px;
    }

    .items-table .item-name {
      font-weight: bold;
    }

    .items-table .item-details {
      font-size: 9px;
      color: #666;
    }

    .totals {
      border-top: 1px solid #000;
      padding-top: 8px;
      margin-top: 8px;
    }

    .totals div {
      display: flex;
      justify-content: space-between;
      margin: 3px 0;
      font-size: 11px;
    }

    .totals .grand-total {
      font-size: 14px;
      font-weight: bold;
      border-top: 2px solid #000;
      padding-top: 5px;
      margin-top: 5px;
    }

    .payment-info {
      border-top: 1px dashed #000;
      padding-top: 8px;
      margin-top: 8px;
      font-size: 11px;
    }

    .payment-info div {
      display: flex;
      justify-content: space-between;
      margin: 3px 0;
    }

    .ticket-footer {
      text-align: center;
      border-top: 2px dashed #000;
      padding-top: 10px;
      margin-top: 15px;
      font-size: 10px;
    }

    .print-button {
      display: block;
      width: 100%;
      padding: 10px;
      margin: 20px 0;
      background: #3B82F6;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
    }

    @media print {
      .print-button {
        display: none;
      }
    }
  </style>
</head>

<body>
  <button class="print-button" onclick="window.print()">🖨️ Imprimer le Ticket</button>

  <div class="ticket">
    <!-- En-tête -->
    <div class="ticket-header">
      <h1>🍺 ETS DUBAI</h1>
      <p><?php echo e($vente->pointVente->nom); ?></p>
      <p><?php echo e($vente->pointVente->adresse ?? 'Sangmelima, Sud Cameroun'); ?></p>
      <p>Tél: <?php echo e($vente->pointVente->telephone ?? '+237 ^85 24 56 32'); ?></p>
    </div>

    <!-- Informations vente -->
    <div class="ticket-info">
      <div>
        <strong>N° Vente:</strong>
        <span><?php echo e($vente->numero_vente); ?></span>
      </div>
      <div>
        <strong>Date:</strong>
        <span><?php echo e($vente->date_vente->format('d/m/Y H:i')); ?></span>
      </div>
      <div>
        <strong>Vendeur:</strong>
        <span><?php echo e($vente->user->name); ?></span>
      </div>
      <?php if($vente->client): ?>
        <div>
          <strong>Client:</strong>
          <span><?php echo e($vente->client->nom); ?></span>
        </div>
      <?php endif; ?>
      <?php if($vente->caisse): ?>
        <div>
          <strong>Caisse:</strong>
          <span><?php echo e($vente->caisse->nom_caisse); ?></span>
        </div>
      <?php endif; ?>
    </div>

    <!-- Articles -->
    <table class="items-table">
      <thead>
        <tr>
          <th style="width: 60%">Article</th>
          <th style="width: 15%; text-align: center">Qté</th>
          <th style="width: 25%; text-align: right">Total</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $vente->lignes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ligne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <div class="item-name"><?php echo e($ligne->produit->nom); ?></div>
              <div class="item-details">
                <?php echo e(number_format($ligne->prix_unitaire_ttc, 0, ',', ' ')); ?> FCFA x <?php echo e($ligne->quantite); ?>

              </div>
            </td>
            <td style="text-align: center"><?php echo e($ligne->quantite); ?></td>
            <td style="text-align: right"><?php echo e(number_format($ligne->montant_total, 0, ',', ' ')); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    <!-- Totaux -->
    <div class="totals">
      <div>
        <span>Sous-total HT:</span>
        <span><?php echo e(number_format($vente->montant_ht, 0, ',', ' ')); ?> FCFA</span>
      </div>
      <div>
        <span>TVA (19.25%):</span>
        <span><?php echo e(number_format($vente->montant_tva, 0, ',', ' ')); ?> FCFA</span>
      </div>
      <?php if($vente->remise_globale > 0): ?>
        <div style="color: #d00">
          <span>Remise (<?php echo e($vente->remise_globale); ?>%):</span>
          <span>-<?php echo e(number_format($vente->montant_ht * ($vente->remise_globale / 100), 0, ',', ' ')); ?> FCFA</span>
        </div>
      <?php endif; ?>
      <div class="grand-total">
        <span>TOTAL À PAYER:</span>
        <span><?php echo e(number_format($vente->montant_total, 0, ',', ' ')); ?> FCFA</span>
      </div>
    </div>

    <!-- Paiement -->
    <div class="payment-info">
      <div>
        <span>Mode de paiement:</span>
        <strong>
          <?php if($vente->type_paiement === 'especes'): ?>
            Espèces
          <?php elseif($vente->type_paiement === 'mobile_money'): ?>
            Mobile Money
          <?php elseif($vente->type_paiement === 'credit'): ?>
            Crédit
          <?php else: ?>
            <?php echo e(ucfirst($vente->type_paiement)); ?>

          <?php endif; ?>
        </strong>
      </div>
      <div>
        <span>Montant payé:</span>
        <span><?php echo e(number_format($vente->montant_paye, 0, ',', ' ')); ?> FCFA</span>
      </div>
      <?php if($vente->montant_rendu > 0): ?>
        <div>
          <span>Rendu:</span>
          <strong><?php echo e(number_format($vente->montant_rendu, 0, ',', ' ')); ?> FCFA</strong>
        </div>
      <?php endif; ?>
    </div>

    <!-- Pied de page -->
    <div class="ticket-footer">
      <p><strong>Merci pour votre visite !</strong></p>
      <p>À bientôt chez ETS DUBAI</p>
      <p style="margin-top: 10px; font-size: 9px;">
        Articles: <?php echo e($vente->lignes->sum('quantite')); ?> | Lignes: <?php echo e($vente->lignes->count()); ?>

      </p>
      <p style="font-size: 9px;">
        Imprimé le <?php echo e(now()->format('d/m/Y à H:i')); ?>

      </p>
    </div>
  </div>

  <script>
    // Auto-print on load (optional)
    // window.onload = function() { window.print(); }
  </script>
</body>

</html><?php /**PATH C:\Users\Gebruiker\Documents\Docs_programmation\Professionnel\Annee-2025\ets-dubai\ETS-DUBAI\resources\views/ventes/ticket.blade.php ENDPATH**/ ?>