<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['items']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['items']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<nav class="flex mb-6" aria-label="Breadcrumb">
  <ol class="inline-flex items-center space-x-1 md:space-x-3">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li <?php if($index === 0): ?> class="inline-flex items-center" <?php endif; ?>>
        <?php if($index > 0): ?>
          <div class="flex items-center">
            <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd"
                d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                clip-rule="evenodd" />
            </svg>
        <?php endif; ?>

          <?php if(isset($item['url']) && !$loop->last): ?>
            <a href="<?php echo e($item['url']); ?>"
              class="<?php if($index === 0): ?> text-gray-700 hover:text-primary-600 transition-colors <?php else: ?> ml-1 text-gray-700 hover:text-primary-600 transition-colors <?php endif; ?>">
              <?php if(isset($item['icon'])): ?>
                <?php echo $item['icon']; ?>

              <?php endif; ?>
              <?php echo e($item['label']); ?>

            </a>
          <?php else: ?>
            <span class="<?php if($index === 0): ?> text-gray-500 <?php else: ?> ml-1 text-gray-500 <?php endif; ?>">
              <?php echo e($item['label']); ?>

            </span>
          <?php endif; ?>

          <?php if($index > 0): ?>
            </div>
          <?php endif; ?>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ol>
</nav><?php /**PATH C:\Users\Gebruiker\Documents\Docs_programmation\Professionnel\Annee-2025\ets-dubai\ETS-DUBAI\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>