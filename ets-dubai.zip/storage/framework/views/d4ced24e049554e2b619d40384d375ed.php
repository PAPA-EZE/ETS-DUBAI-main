

<?php $__env->startSection('title', 'Nouvel Utilisateur'); ?>
<?php $__env->startSection('page-title', 'Nouvel Utilisateur'); ?>

<?php $__env->startSection('content'); ?>
  <div class="fade-in">
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
      ['label' => 'Utilisateurs', 'url' => route('admin.users.index')],
      ['label' => 'Nouveau', 'url' => null],
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>

    <div class="max-w-3xl mx-auto">
      <div class="mb-6">
        <h2 class="text-2xl font-bold text-gray-900">Créer un Nouvel Utilisateur</h2>
        <p class="text-gray-600 mt-1">Ajoutez un nouveau membre à votre équipe</p>
      </div>

      <div class="card">
        <div class="p-6">
          <form action="<?php echo e(route('admin.users.store')); ?>" method="POST" id="userForm">
            <?php echo csrf_field(); ?>

            <!-- Informations de base -->
            <div class="mb-8">
              <h3 class="text-lg font-semibold text-gray-900 mb-4">Informations de Base</h3>

              <div class="space-y-6">
                <!-- Nom -->
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Nom complet <span class="text-danger-600">*</span>
                  </label>
                  <input type="text" name="name" value="<?php echo e(old('name')); ?>" required
                    class="input-field <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ex: Jean Dupont">
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Email -->
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Adresse email <span class="text-danger-600">*</span>
                  </label>
                  <input type="email" name="email" value="<?php echo e(old('email')); ?>" required
                    class="input-field <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="email@exemple.com">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Rôle -->
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Rôle <span class="text-danger-600">*</span>
                  </label>
                  <select name="role" id="role" required class="input-field <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    onchange="togglePointVente()">
                    <option value="">Sélectionnez un rôle...</option>
                    <option value="admin" <?php echo e(old('role') == 'admin' ? 'selected' : ''); ?>>Administrateur</option>
                    <option value="responsable" <?php echo e(old('role') == 'responsable' ? 'selected' : ''); ?>>Responsable</option>
                    <option value="vendeur" <?php echo e(old('role') == 'vendeur' ? 'selected' : ''); ?>>Vendeur</option>
                  </select>
                  <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <p class="mt-1 text-xs text-gray-500">
                    <strong>Admin :</strong> Accès complet au système.<br>
                    <strong>Responsable :</strong> Gestion des stocks, commandes et transferts.<br>
                    <strong>Vendeur :</strong> Accès aux ventes et caisses.
                  </p>
                </div>

                <!-- Point de Vente -->
                <div id="pointVenteField" style="display: none;">
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Point de Vente <span class="text-danger-600">*</span>
                  </label>
                  <select name="point_vente_id" id="point_vente_id"
                    class="input-field <?php $__errorArgs = ['point_vente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="">Sélectionnez un point de vente...</option>
                    <?php $__currentLoopData = $pointsVente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($point->id); ?>" <?php echo e(old('point_vente_id') == $point->id ? 'selected' : ''); ?>>
                        <?php echo e($point->nom); ?> (<?php echo e($point->code); ?>)
                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php $__errorArgs = ['point_vente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php if($pointsVente->isEmpty()): ?>
                    <p class="mt-1 text-sm text-warning-600">⚠️ Aucun point de vente disponible</p>
                  <?php else: ?>
                    <p class="mt-1 text-xs text-gray-500">
                      Le point de vente principal de l'utilisateur
                    </p>
                  <?php endif; ?>
                </div>
              </div>
            </div>

            <!-- Mot de passe -->
            <div class="mb-8">
              <h3 class="text-lg font-semibold text-gray-900 mb-4">Mot de Passe</h3>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Mot de passe <span class="text-danger-600">*</span>
                  </label>
                  <input type="password" name="password" required
                    class="input-field <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Minimum 8 caractères">
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Confirmer le mot de passe <span class="text-danger-600">*</span>
                  </label>
                  <input type="password" name="password_confirmation" required class="input-field"
                    placeholder="Confirmez le mot de passe">
                </div>
              </div>
            </div>

            <!-- Statut -->
            <div class="mb-8">
              <h3 class="text-lg font-semibold text-gray-900 mb-4">Statut du Compte</h3>

              <div class="flex items-center">
                <input type="checkbox" name="actif" id="actif" value="1" <?php echo e(old('actif', true) ? 'checked' : ''); ?>

                  class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded">
                <label for="actif" class="ml-2 text-sm text-gray-700">
                  Compte actif (l'utilisateur pourra se connecter)
                </label>
              </div>
            </div>

            <!-- Boutons -->
            <div class="flex items-center justify-end gap-3 pt-6 border-t border-gray-200">
              <a href="<?php echo e(route('admin.users.index')); ?>" class="btn-secondary">
                Annuler
              </a>
              <button type="submit" class="btn-primary">
                <svg class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round"
                    d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Créer l'Utilisateur
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Afficher/masquer le champ point de vente selon le rôle
    function togglePointVente() {
      const role = document.getElementById('role').value;
      const pointVenteField = document.getElementById('pointVenteField');
      const pointVenteSelect = document.getElementById('point_vente_id');

      // Point de vente pour TOUS les rôles (admin, responsable, vendeur)
      if (role === 'admin' || role === 'responsable' || role === 'vendeur') {
        pointVenteField.style.display = 'block';
        pointVenteSelect.setAttribute('required', 'required');
      } else {
        pointVenteField.style.display = 'none';
        pointVenteSelect.removeAttribute('required');
        pointVenteSelect.value = '';
      }
    }

    // Appeler la fonction au chargement de la page si un rôle est déjà sélectionné
    document.addEventListener('DOMContentLoaded', function () {
      togglePointVente();
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Gebruiker\Documents\Docs_programmation\Professionnel\Annee-2025\ets-dubai\ETS-DUBAI\resources\views/admin/users/create.blade.php ENDPATH**/ ?>