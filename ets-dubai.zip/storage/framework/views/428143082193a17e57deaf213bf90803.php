

<?php $__env->startSection('title', 'Nouvelle Commande'); ?>
<?php $__env->startSection('page-title', 'Nouvelle Commande'); ?>

<?php $__env->startSection('content'); ?>
  <div class="fade-in" x-data="commandeForm()">
    <!-- Breadcrumb -->
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
      ['label' => 'Commandes', 'url' => route('commandes.index'), 'icon' => '<svg class=\'w-4 h-4 mr-2\' fill=\'none\' viewBox=\'0 0 24 24\' stroke-width=\'1.5\' stroke=\'currentColor\'><path stroke-linecap=\'round\' stroke-linejoin=\'round\' d=\'M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.119-1.243l1.263-12C4.468 8.79 4.776 8.5 5.154 8.5h13.692a.75.75 0 01.119 1.007z\' /></svg>'],
      ['label' => 'Nouvelle commande'],
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>

    <!-- Header -->
    <div class="page-header">
      <div>
        <h1 class="text-2xl font-bold text-gray-900">Nouvelle Commande</h1>
        <p class="mt-1 text-sm text-gray-600">
          Créez une nouvelle commande auprès de vos fournisseurs
        </p>
      </div>
    </div>

    <!-- Formulaire -->
    <form method="POST" action="<?php echo e(route('commandes.store')); ?>" class="space-y-6">
      <?php echo csrf_field(); ?>

      <!-- Informations générales -->
      <div class="card p-6">
        <h3 class="text-lg font-medium text-gray-900 mb-6">Informations générales</h3>

        <div class="grid grid-cols-1 gap-6 sm:grid-cols-3">
          <!-- Fournisseur -->
          <div class="sm:col-span-2">
            <label for="fournisseur_id" class="block text-sm font-medium text-gray-700">
              Fournisseur <span class="text-danger-500">*</span>
            </label>
            <select name="fournisseur_id" id="fournisseur_id" x-model="fournisseurId"
              @change="chargerProduitsFournisseur()"
              class="mt-1 input-field <?php $__errorArgs = ['fournisseur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <option value="">Sélectionnez un fournisseur</option>
              <?php $__currentLoopData = $fournisseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fournisseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($fournisseur->id); ?>" <?php echo e(old('fournisseur_id', $fournisseur_id) == $fournisseur->id ? 'selected' : ''); ?>>
                  <?php echo e($fournisseur->nom); ?> (Ristourne: <?php echo e($fournisseur->taux_ristourne_defaut); ?>%)
                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['fournisseur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-2 text-sm text-danger-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- Date de commande -->
          <div>
            <label for="date_commande" class="block text-sm font-medium text-gray-700">
              Date de commande <span class="text-danger-500">*</span>
            </label>
            <input type="date" name="date_commande" id="date_commande" value="<?php echo e(old('date_commande', date('Y-m-d'))); ?>"
              class="mt-1 input-field <?php $__errorArgs = ['date_commande'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['date_commande'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-2 text-sm text-danger-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- Date de livraison prévue -->
          <div>
            <label for="date_livraison_prevue" class="block text-sm font-medium text-gray-700">
              Livraison prévue
            </label>
            <input type="date" name="date_livraison_prevue" id="date_livraison_prevue"
              value="<?php echo e(old('date_livraison_prevue')); ?>"
              class="mt-1 input-field <?php $__errorArgs = ['date_livraison_prevue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['date_livraison_prevue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-2 text-sm text-danger-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- Notes -->
          <div class="sm:col-span-3">
            <label for="notes" class="block text-sm font-medium text-gray-700">
              Notes
            </label>
            <textarea name="notes" id="notes" rows="3"
              class="mt-1 input-field <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
              placeholder="Notes et instructions pour cette commande..."><?php echo e(old('notes')); ?></textarea>
            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-2 text-sm text-danger-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
      </div>

      <!-- Articles de la commande -->
      <div class="card p-6">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-lg font-medium text-gray-900">Articles de la commande</h3>
          <button type="button" @click="ajouterLigne()" class="btn-secondary">
            <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            Ajouter une ligne
          </button>
        </div>

        <!-- Message si aucun fournisseur sélectionné -->
        <div x-show="!fournisseurId" class="text-center py-8 text-gray-500">
          <svg class="mx-auto h-8 w-8 text-gray-400 mb-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
            stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5.25h.008v.008H12v-.008z" />
          </svg>
          <p>Sélectionnez d'abord un fournisseur pour ajouter des produits</p>
        </div>

        <!-- Table des articles -->
        <div x-show="fournisseurId" class="space-y-4">
          <template x-for="(item, index) in items" :key="index">
            <div class="border border-gray-200 rounded-lg p-4 bg-gray-50">
              <div class="grid grid-cols-1 gap-4 sm:grid-cols-12 items-end">
                <!-- Produit -->
                <div class="sm:col-span-5">
                  <label class="block text-sm font-medium text-gray-700 mb-1">
                    Produit <span class="text-danger-500">*</span>
                  </label>
                  <select :name="`items[${index}][produit_id]`" x-model="item.produit_id" @change="mettreAJourPrix(index)"
                    class="input-field">
                    <option value="">Sélectionnez un produit</option>
                    <template x-for="produit in produitsDisponibles" :key="produit.id">
                      <option :value="produit.id"
                        x-text="`${produit.nom} - ${produit.reference} (Stock: ${produit.stock_actuel})`"></option>
                    </template>
                  </select>
                </div>

                <!-- Quantité -->
                <div class="sm:col-span-2">
                  <label class="block text-sm font-medium text-gray-700 mb-1">
                    Quantité <span class="text-danger-500">*</span>
                  </label>
                  <input type="number" :name="`items[${index}][quantite]`" x-model="item.quantite"
                    @input="calculerMontantLigne(index)" min="1" class="input-field" placeholder="0">
                </div>

                <!-- Prix unitaire -->
                <div class="sm:col-span-2">
                  <label class="block text-sm font-medium text-gray-700 mb-1">
                    Prix unitaire (FCFA) <span class="text-danger-500">*</span>
                  </label>
                  <input type="number" :name="`items[${index}][prix_unitaire]`" x-model="item.prix_unitaire"
                    @input="calculerMontantLigne(index)" min="0" step="0.01" class="input-field" placeholder="0">
                </div>

                <!-- Montant ligne -->
                <div class="sm:col-span-2">
                  <label class="block text-sm font-medium text-gray-700 mb-1">
                    Montant ligne
                  </label>
                  <div class="input-field bg-gray-100" x-text="formatCurrency(item.montant_ligne)"></div>
                </div>

                <!-- Actions -->
                <div class="sm:col-span-1">
                  <button type="button" @click="supprimerLigne(index)"
                    class="w-full h-10 flex items-center justify-center text-danger-600 hover:text-danger-800 hover:bg-danger-50 rounded-lg transition-colors">
                    <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round"
                        d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </template>

          <!-- Message si aucun article -->
          <div x-show="items.length === 0" class="text-center py-8 text-gray-500">
            <svg class="mx-auto h-8 w-8 text-gray-400 mb-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
              stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round"
                d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
            </svg>
            <p>Aucun article dans la commande</p>
            <button type="button" @click="ajouterLigne()" class="mt-2 btn-primary">
              Ajouter le premier article
            </button>
          </div>
        </div>
      </div>

      <!-- Récapitulatif -->
      <div x-show="items.length > 0" class="card p-6">
        <h3 class="text-lg font-medium text-gray-900 mb-6">Récapitulatif</h3>

        <div class="grid grid-cols-1 gap-6 sm:grid-cols-3">
          <div class="text-center p-4 bg-gray-50 rounded-lg">
            <div class="text-sm font-medium text-gray-500">Total HT</div>
            <div class="text-2xl font-bold text-gray-900" x-text="formatCurrency(totalHT)"></div>
          </div>

          <div class="text-center p-4 bg-blue-50 rounded-lg">
            <div class="text-sm font-medium text-blue-600">TVA (19.25%)</div>
            <div class="text-2xl font-bold text-blue-900" x-text="formatCurrency(totalTVA)"></div>
          </div>

          <div class="text-center p-4 bg-primary-50 rounded-lg">
            <div class="text-sm font-medium text-primary-600">Total TTC</div>
            <div class="text-2xl font-bold text-primary-900" x-text="formatCurrency(totalTTC)"></div>
          </div>
        </div>

        <div x-show="ristournePrevue > 0" class="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
          <div class="flex items-center">
            <svg class="h-5 w-5 text-green-600 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
              stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round"
                d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <div>
              <p class="text-sm font-medium text-green-800">
                Ristourne prévue: <span x-text="formatCurrency(ristournePrevue)"></span>
              </p>
              <p class="text-xs text-green-600">
                Économie réalisée grâce aux conditions négociées
              </p>
            </div>
          </div>
        </div>
      </div>

      <!-- Actions -->
      <div class="flex justify-end space-x-3">
        <a href="<?php echo e(route('commandes.index')); ?>" class="btn-secondary">
          <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
          Annuler
        </a>

        <button type="submit" name="action" value="brouillon" class="btn-secondary">
          <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M16.5 3.75V16.5L12 14.25 7.5 16.5V3.75a.75.75 0 01.75-.75h7.5a.75.75 0 01.75.75z" />
          </svg>
          Sauvegarder comme brouillon
        </button>

        <button type="submit" name="envoyer" value="1" class="btn-primary">
          <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.768 59.768 0 013.27 20.876L5.999 12zm0 0h7.5" />
          </svg>
          Créer et envoyer
        </button>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script>
    function commandeForm() {
      return {
        fournisseurId: '<?php echo e(old('fournisseur_id', $fournisseur_id)); ?>',
        produitsTous: <?php echo json_encode($produits, 15, 512) ?>, // CORRECTION: Charger tous les produits depuis le controller
        produitsDisponibles: [],
        items: [],

        get totalHT() {
          return this.items.reduce((total, item) => total + (item.montant_ligne || 0), 0);
        },

        get totalTVA() {
          return this.totalHT * 0.1925;
        },

        get totalTTC() {
          return this.totalHT + this.totalTVA;
        },

        get ristournePrevue() {
          if (!this.fournisseurId) return 0;
          const fournisseur = <?php echo json_encode($fournisseurs, 15, 512) ?>.find(f => f.id == this.fournisseurId);
          return fournisseur ? (this.totalHT * fournisseur.taux_ristourne_defaut / 100) : 0;
        },

        // CORRECTION: Filtrer les produits côté client au lieu d'appeler une API
        chargerProduitsFournisseur() {
          if (!this.fournisseurId) {
            this.produitsDisponibles = [];
            return;
          }

          // Filtrer les produits qui appartiennent au fournisseur sélectionné
          this.produitsDisponibles = this.produitsTous.filter(p => p.fournisseur_id == this.fournisseurId);
        },

        ajouterLigne() {
          this.items.push({
            produit_id: '',
            quantite: 1,
            prix_unitaire: 0,
            montant_ligne: 0
          });
        },

        supprimerLigne(index) {
          this.items.splice(index, 1);
        },

        mettreAJourPrix(index) {
          const item = this.items[index];
          const produit = this.produitsDisponibles.find(p => p.id == item.produit_id);

          if (produit) {
            item.prix_unitaire = produit.prix_achat;
            this.calculerMontantLigne(index);
          }
        },

        calculerMontantLigne(index) {
          const item = this.items[index];
          item.montant_ligne = (item.quantite || 0) * (item.prix_unitaire || 0);
        },

        formatCurrency(amount) {
          return new Intl.NumberFormat('fr-FR', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
          }).format(amount || 0) + ' FCFA';
        },

        init() {
          if (this.fournisseurId) {
            this.chargerProduitsFournisseur();
          }
        }
      }
    }
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Gebruiker\Documents\Docs_programmation\Professionnel\Annee-2025\ets-dubai\ETS-DUBAI\resources\views/commandes/create.blade.php ENDPATH**/ ?>