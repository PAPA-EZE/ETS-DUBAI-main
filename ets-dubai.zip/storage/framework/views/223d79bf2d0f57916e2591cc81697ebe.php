<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'value', 'subtitle' => null, 'icon', 'color' => 'primary']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'value', 'subtitle' => null, 'icon', 'color' => 'primary']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
  $colorClasses = [
    'primary' => 'bg-primary-100 text-primary-600',
    'success' => 'bg-success-100 text-success-600',
    'warning' => 'bg-accent-100 text-accent-600',
    'danger' => 'bg-danger-100 text-danger-600',
    'info' => 'bg-blue-100 text-blue-600',
  ];

  $iconBg = $colorClasses[$color] ?? $colorClasses['primary'];
?>

<div <?php echo e($attributes->merge(['class' => 'stat-card'])); ?>>
  <div class="flex items-center">
    <div class="flex-shrink-0">
      <div class="h-12 w-12 rounded-full <?php echo e($iconBg); ?> flex items-center justify-center">
        <?php echo $icon; ?>

      </div>
    </div>
    <div class="ml-4 flex-1">
      <p class="text-sm font-medium text-gray-600"><?php echo e($title); ?></p>
      <p class="text-2xl font-bold text-gray-900"><?php echo e($value); ?></p>
      <?php if($subtitle): ?>
        <p class="text-sm text-gray-500"><?php echo e($subtitle); ?></p>
      <?php endif; ?>
    </div>
  </div>
</div><?php /**PATH C:\Users\Gebruiker\Documents\Docs_programmation\Professionnel\Annee-2025\ets-dubai\ETS-DUBAI\resources\views/components/stat-card.blade.php ENDPATH**/ ?>