

<?php $__env->startSection('title', 'Calculer une Ristourne'); ?>
<?php $__env->startSection('page-title', 'Calculer une Ristourne'); ?>

<?php $__env->startSection('content'); ?>
  <div class="fade-in">
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
      ['label' => 'Ristournes', 'url' => route('ristournes.index')],
      ['label' => 'Calculer', 'url' => null],
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>

    <div class="max-w-3xl mx-auto">
      <div class="mb-6">
        <h2 class="text-2xl font-bold text-gray-900">Calculer une Ristourne</h2>
        <p class="text-gray-600 mt-1">Sélectionnez le fournisseur et la période de calcul</p>
      </div>

      <?php if($fournisseurs->count() == 0): ?>
        <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Alert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'warning']); ?>
          Aucun fournisseur n'a de barème de ristourne configuré.
          <a href="<?php echo e(route('fournisseurs.index')); ?>" class="underline font-medium ml-2">Configurer les barèmes</a>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
      <?php else: ?>
        <div class="card">
          <div class="p-6">
            <form action="<?php echo e(route('ristournes.store')); ?>" method="POST">
              <?php echo csrf_field(); ?>

              <!-- Sélection fournisseur -->
              <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Fournisseur <span class="text-danger-600">*</span>
                </label>
                <select name="fournisseur_id" required
                  class="input-field <?php $__errorArgs = ['fournisseur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  <option value="">Sélectionnez un fournisseur...</option>
                  <?php $__currentLoopData = $fournisseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fournisseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($fournisseur->id); ?>" <?php echo e(old('fournisseur_id') == $fournisseur->id ? 'selected' : ''); ?>>
                      <?php echo e($fournisseur->nom); ?> (<?php echo e($fournisseur->baremes_count); ?> barème(s))
                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['fournisseur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <!-- Type de période -->
              <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Type de période <span class="text-danger-600">*</span>
                </label>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <label
                    class="relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none hover:border-primary-500">
                    <input type="radio" name="type_periode" value="mensuel" <?php echo e(old('type_periode', 'mensuel') == 'mensuel' ? 'checked' : ''); ?> class="sr-only">
                    <span class="flex flex-1">
                      <span class="flex flex-col">
                        <span class="block text-sm font-medium text-gray-900">Mensuel</span>
                      </span>
                    </span>
                    <svg class="h-5 w-5 text-primary-600 hidden" viewBox="0 0 20 20" fill="currentColor">
                      <path fill-rule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                        clip-rule="evenodd" />
                    </svg>
                  </label>

                  <label
                    class="relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none hover:border-primary-500">
                    <input type="radio" name="type_periode" value="trimestriel" <?php echo e(old('type_periode') == 'trimestriel' ? 'checked' : ''); ?> class="sr-only">
                    <span class="flex flex-1">
                      <span class="flex flex-col">
                        <span class="block text-sm font-medium text-gray-900">Trimestriel</span>
                      </span>
                    </span>
                  </label>

                  <label
                    class="relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none hover:border-primary-500">
                    <input type="radio" name="type_periode" value="semestriel" <?php echo e(old('type_periode') == 'semestriel' ? 'checked' : ''); ?> class="sr-only">
                    <span class="flex flex-1">
                      <span class="flex flex-col">
                        <span class="block text-sm font-medium text-gray-900">Semestriel</span>
                      </span>
                    </span>
                  </label>

                  <label
                    class="relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none hover:border-primary-500">
                    <input type="radio" name="type_periode" value="annuel" <?php echo e(old('type_periode') == 'annuel' ? 'checked' : ''); ?> class="sr-only">
                    <span class="flex flex-1">
                      <span class="flex flex-col">
                        <span class="block text-sm font-medium text-gray-900">Annuel</span>
                      </span>
                    </span>
                  </label>
                </div>
                <?php $__errorArgs = ['type_periode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <!-- Date de référence -->
              <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Date de référence <span class="text-danger-600">*</span>
                </label>
                <input type="date" name="date_reference" value="<?php echo e(old('date_reference', now()->format('Y-m-d'))); ?>"
                  required class="input-field <?php $__errorArgs = ['date_reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['date_reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="mt-1 text-xs text-gray-500">
                  La période sera calculée automatiquement selon cette date et le type choisi
                </p>
              </div>

              <!-- Info -->
              <div class="mb-6 p-4 bg-info-50 rounded-lg border border-info-200">
                <div class="flex">
                  <svg class="h-5 w-5 text-info-600 mt-0.5" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                      d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
                  </svg>
                  <div class="ml-3">
                    <h4 class="text-sm font-medium text-info-900">Comment ça marche ?</h4>
                    <ul class="mt-2 text-sm text-info-700 space-y-1">
                      <li>• Le système récupère toutes les commandes livrées du fournisseur sur la période</li>
                      <li>• Le barème applicable est déterminé selon le montant total d'achats</li>
                      <li>• La ristourne est calculée automatiquement</li>
                    </ul>
                  </div>
                </div>
              </div>

              <!-- Boutons -->
              <div class="flex items-center justify-end gap-3">
                <a href="<?php echo e(route('ristournes.index')); ?>" class="btn-secondary">
                  Annuler
                </a>
                <button type="submit" class="btn-primary">
                  Calculer la Ristourne
                </button>
              </div>
            </form>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <?php $__env->startPush('scripts'); ?>
    <script>
      // Gérer l'apparence visuelle des radio buttons
      document.querySelectorAll('input[type="radio"]').forEach(radio => {
        radio.addEventListener('change', function () {
          document.querySelectorAll('input[type="radio"][name="' + this.name + '"]').forEach(r => {
            r.closest('label').classList.remove('border-primary-500', 'ring-2', 'ring-primary-500');
            r.nextElementSibling.querySelector('svg').classList.add('hidden');
          });

          if (this.checked) {
            this.closest('label').classList.add('border-primary-500', 'ring-2', 'ring-primary-500');
            this.nextElementSibling.querySelector('svg').classList.remove('hidden');
          }
        });

        // Init au chargement
        if (radio.checked) {
          radio.closest('label').classList.add('border-primary-500', 'ring-2', 'ring-primary-500');
          radio.nextElementSibling.querySelector('svg').classList.remove('hidden');
        }
      });
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Gebruiker\Documents\Docs_programmation\Professionnel\Annee-2025\ets-dubai\ETS-DUBAI\resources\views/ristournes/create.blade.php ENDPATH**/ ?>