

<?php $__env->startSection('title', 'Modifier ' . $user->name); ?>
<?php $__env->startSection('page-title', 'Modifier l\'Utilisateur'); ?>

<?php $__env->startSection('content'); ?>
  <div class="fade-in">
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
      ['label' => 'Utilisateurs', 'url' => route('admin.users.index')],
      ['label' => $user->name, 'url' => route('admin.users.show', $user)],
      ['label' => 'Modifier', 'url' => null],
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>

    <div class="max-w-3xl mx-auto">
      <div class="mb-6">
        <h2 class="text-2xl font-bold text-gray-900">Modifier l'Utilisateur</h2>
        <p class="text-gray-600 mt-1"><?php echo e($user->name); ?></p>
      </div>

      <div class="card">
        <div class="p-6">
          <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Informations de base -->
            <div class="mb-8">
              <h3 class="text-lg font-semibold text-gray-900 mb-4">Informations de Base</h3>

              <div class="space-y-6">
                <!-- Nom -->
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Nom complet <span class="text-danger-600">*</span>
                  </label>
                  <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" required
                    class="input-field <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Email -->
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Adresse email <span class="text-danger-600">*</span>
                  </label>
                  <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required
                    class="input-field <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Rôle -->
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Rôle <span class="text-danger-600">*</span>
                  </label>
                  <select name="role" id="role" required class="input-field <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" <?php echo e($user->id === auth()->id() ? 'disabled' : ''); ?> onchange="togglePointVente()">
                    <option value="admin" <?php echo e(old('role', $user->role) == 'admin' ? 'selected' : ''); ?>>Administrateur
                    </option>
                    <option value="responsable" <?php echo e(old('role', $user->role) == 'responsable' ? 'selected' : ''); ?>>
                      Responsable</option>
                    <option value="vendeur" <?php echo e(old('role', $user->role) == 'vendeur' ? 'selected' : ''); ?>>Vendeur</option>
                  </select>
                  <?php if($user->id === auth()->id()): ?>
                    <input type="hidden" name="role" value="<?php echo e($user->role); ?>">
                    <p class="mt-1 text-xs text-warning-600">Vous ne pouvez pas modifier votre propre rôle</p>
                  <?php else: ?>
                    <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php endif; ?>
                </div>

                <!-- Point de Vente (visible uniquement si rôle = vendeur) -->
                <div id="pointVenteField" style="display: none;">
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Point de Vente <span class="text-danger-600">*</span>
                  </label>
                  <select name="point_vente_id" id="point_vente_id"
                    class="input-field <?php $__errorArgs = ['point_vente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="">Sélectionnez un point de vente...</option>
                    <?php $__currentLoopData = $pointsVente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($point->id); ?>" <?php echo e(old('point_vente_id', $user->point_vente_id) == $point->id ? 'selected' : ''); ?>>
                        <?php echo e($point->nom); ?> (<?php echo e($point->code); ?>)
                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php $__errorArgs = ['point_vente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-danger-600"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <p class="mt-1 text-xs text-gray-500">
                    Chaque point de vente ne peut être assigné qu'à un seul vendeur
                  </p>
                </div>
              </div>
            </div>

            <!-- Statut -->
            <div class="mb-8">
              <h3 class="text-lg font-semibold text-gray-900 mb-4">Statut du Compte</h3>

              <div class="flex items-center">
                <input type="checkbox" name="actif" id="actif" value="1" <?php echo e(old('actif', $user->actif) ? 'checked' : ''); ?>

                  <?php echo e($user->id === auth()->id() ? 'disabled' : ''); ?>

                  class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded">
                <label for="actif" class="ml-2 text-sm text-gray-700">
                  Compte actif (l'utilisateur pourra se connecter)
                </label>
                <?php if($user->id === auth()->id()): ?>
                  <input type="hidden" name="actif" value="1">
                <?php endif; ?>
              </div>
              <?php if($user->id === auth()->id()): ?>
                <p class="mt-2 text-xs text-warning-600">Vous ne pouvez pas désactiver votre propre compte</p>
              <?php endif; ?>
            </div>

            <!-- Info modification mot de passe -->
            <div class="mb-8 p-4 bg-info-50 rounded-lg border border-info-200">
              <p class="text-sm text-info-900">
                <strong>Note :</strong> Pour modifier le mot de passe, utilisez la fonctionnalité
                "Réinitialiser le mot de passe" sur la page de détails de l'utilisateur.
              </p>
            </div>

            <!-- Boutons -->
            <div class="flex items-center justify-between pt-6 border-t border-gray-200">
              <div>
                <?php if($user->id !== auth()->id() && !$user->ventes()->exists()): ?>
                  <button type="button"
                    onclick="if(confirm('Voulez-vous vraiment supprimer cet utilisateur ?')) { document.getElementById('delete-form').submit(); }"
                    class="btn-danger">
                    Supprimer
                  </button>
                <?php endif; ?>
              </div>
              <div class="flex items-center gap-3">
                <a href="<?php echo e(route('admin.users.show', $user)); ?>" class="btn-secondary">
                  Annuler
                </a>
                <button type="submit" class="btn-primary">
                  Enregistrer les Modifications
                </button>
              </div>
            </div>
          </form>

          <!-- Formulaire de suppression caché -->
          <?php if($user->id !== auth()->id() && !$user->ventes()->exists()): ?>
            <form id="delete-form" action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST" class="hidden">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
            </form>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Afficher/masquer le champ point de vente selon le rôle
    function togglePointVente() {
      const role = document.getElementById('role').value;
      const pointVenteField = document.getElementById('pointVenteField');
      const pointVenteSelect = document.getElementById('point_vente_id');

      // Point de vente obligatoire pour vendeur et responsable
      if (role === 'vendeur' || role === 'responsable') {
        pointVenteField.style.display = 'block';
        pointVenteSelect.setAttribute('required', 'required');
      } else {
        pointVenteField.style.display = 'none';
        pointVenteSelect.removeAttribute('required');
        pointVenteSelect.value = '';
      }
    }

    // Appeler la fonction au chargement de la page
    document.addEventListener('DOMContentLoaded', function () {
      togglePointVente();
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Gebruiker\Documents\Docs_programmation\Professionnel\Annee-2025\ets-dubai\ETS-DUBAI\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>