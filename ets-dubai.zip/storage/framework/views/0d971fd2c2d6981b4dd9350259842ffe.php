

<?php $__env->startSection('title', 'Produits'); ?>
<?php $__env->startSection('page-title', 'Gestion des Produits'); ?>

<?php $__env->startSection('content'); ?>
  <div class="fade-in">
    <!-- Header avec actions -->
    <div class="page-header">
      <div>
        <h1 class="text-2xl font-bold text-gray-900">Produits</h1>
        <p class="mt-1 text-sm text-gray-600">
          Gérez votre catalogue de produits et surveillez vos stocks
        </p>
      </div>
      <div class="mt-4 sm:mt-0">
        <a href="<?php echo e(route('produits.create')); ?>" class="btn-primary">
          <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
          </svg>
          Nouveau Produit
        </a>
      </div>
    </div>

    <!-- Alertes de stock -->
    <?php
      $produits_rupture = $produits->where('stock_actuel', '<=', 0)->count();
      $produits_faible = $produits->filter(function ($p) {
        return $p->stock_actuel > 0 && $p->stock_actuel <= $p->stock_minimum;
      })->count();
    ?>

    <?php if($produits_rupture > 0 || $produits_faible > 0): ?>
      <div class="mb-6">
        <div class="card p-4">
          <div class="flex">
            <div class="flex-shrink-0">
              <svg class="h-5 w-5 text-accent-400" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round"
                  d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
              </svg>
            </div>
            <div class="ml-3">
              <h3 class="text-sm font-medium text-accent-800">Alertes de stock</h3>
              <div class="mt-2 text-sm text-accent-700">
                <?php if($produits_rupture > 0): ?>
                  <span class="font-medium"><?php echo e($produits_rupture); ?></span> produit(s) en rupture de stock.
                <?php endif; ?>
                <?php if($produits_faible > 0): ?>
                  <?php if($produits_rupture > 0): ?> • <?php endif; ?>
                  <span class="font-medium"><?php echo e($produits_faible); ?></span> produit(s) avec un stock faible.
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php endif; ?>

    <!-- Filtres et recherche -->
    <div class="card p-6 mb-6">
      <form method="GET" action="<?php echo e(route('produits.index')); ?>" class="space-y-4">
        <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <!-- Recherche -->
          <div class="lg:col-span-2">
            <label for="search" class="sr-only">Rechercher</label>
            <div class="relative">
              <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                  stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round"
                    d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                </svg>
              </div>
              <input type="text" name="search" id="search" value="<?php echo e(request('search')); ?>" class="input-field pl-10"
                placeholder="Nom, référence, code-barres...">
            </div>
          </div>

          <!-- Catégorie -->
          <div>
            <select name="categorie" class="input-field">
              <option value="">Toutes catégories</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($categorie->id); ?>" <?php echo e(request('categorie') == $categorie->id ? 'selected' : ''); ?>>
                  <?php echo e($categorie->nom); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <!-- Fournisseur -->
          <div>
            <select name="fournisseur" class="input-field">
              <option value="">Tous fournisseurs</option>
              <?php $__currentLoopData = $fournisseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fournisseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($fournisseur->id); ?>" <?php echo e(request('fournisseur') == $fournisseur->id ? 'selected' : ''); ?>>
                  <?php echo e($fournisseur->nom); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <!-- Statut stock -->
          <div>
            <select name="stock_statut" class="input-field">
              <option value="">Tous stocks</option>
              <option value="rupture" <?php echo e(request('stock_statut') === 'rupture' ? 'selected' : ''); ?>>Rupture</option>
              <option value="faible" <?php echo e(request('stock_statut') === 'faible' ? 'selected' : ''); ?>>Stock faible</option>
              <option value="normal" <?php echo e(request('stock_statut') === 'normal' ? 'selected' : ''); ?>>Stock normal</option>
            </select>
          </div>
        </div>

        <div class="flex justify-between">
          <div class="flex space-x-2">
            <button type="submit" class="btn-primary">
              <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round"
                  d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
              </svg>
              Filtrer
            </button>

            <?php if(request()->hasAny(['search', 'categorie', 'fournisseur', 'stock_statut'])): ?>
              <a href="<?php echo e(route('produits.index')); ?>" class="btn-secondary">
                <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
                Réinitialiser
              </a>
            <?php endif; ?>
          </div>

          <!-- Actions rapides -->
          <div class="flex space-x-2">
            <button type="button" class="btn-secondary">
              <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round"
                  d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
              </svg>
              Exporter
            </button>
          </div>
        </div>
      </form>
    </div>

    <!-- Grille des produits -->
    <?php if($produits->count() > 0): ?>
      <div class="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card hover:shadow-lg transition-all duration-300">
            <!-- Image du produit -->
            <div class="aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-t-xl bg-gray-100 relative">
              <div class="flex items-center justify-center h-48">
                <svg class="h-16 w-16 text-gray-400" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round"
                    d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
                </svg>
              </div>

              <!-- Badge catégorie -->
              <div class="absolute top-2 left-2">
                <span
                  class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                  <?php echo e($produit->categorie->nom); ?>

                </span>
              </div>

              <!-- Badge statut stock -->
              <div class="absolute top-2 right-2">
                <?php if($produit->stock_actuel <= 0): ?>
                  <span
                    class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-danger-100 text-danger-800">
                    Rupture
                  </span>
                <?php elseif($produit->stock_actuel <= $produit->stock_minimum): ?>
                  <span
                    class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-accent-100 text-accent-800">
                    Stock faible
                  </span>
                <?php else: ?>
                  <span
                    class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-success-100 text-success-800">
                    En stock
                  </span>
                <?php endif; ?>
              </div>
            </div>

            <!-- Contenu -->
            <div class="p-4">
              <div class="mb-2">
                <h3 class="text-sm font-medium text-gray-900 line-clamp-2"><?php echo e($produit->nom); ?></h3>
                <p class="text-xs text-gray-500"><?php echo e($produit->reference); ?></p>
              </div>

              <div class="mb-3">
                <p class="text-xs text-gray-500"><?php echo e($produit->fournisseur->nom); ?></p>
              </div>

              <!-- Prix et stock -->
              <div class="space-y-2 mb-4">
                <!-- Prix par conditionnement -->
                <div class="bg-blue-50 px-3 py-2 rounded-lg">
                  <div class="flex justify-between items-center">
                    <span class="text-xs text-blue-600 font-medium"><?php echo e($produit->libelle_conditionnement); ?></span>
                    <span class="text-sm font-bold text-blue-900">
                      <?php echo e(number_format($produit->prix_vente_conditionnement, 0, ',', ' ')); ?> F
                    </span>
                  </div>
                </div>

                <!-- Prix par unité -->
                <div class="bg-green-50 px-3 py-2 rounded-lg">
                  <div class="flex justify-between items-center">
                    <span class="text-xs text-green-600 font-medium"><?php echo e($produit->libelle_unite); ?></span>
                    <span class="text-sm font-bold text-green-900">
                      <?php echo e(number_format($produit->prix_vente_unite, 0, ',', ' ')); ?> F
                    </span>
                  </div>
                </div>

                <!-- Stock et marge -->
                <div class="flex justify-between items-center pt-2 border-t">
                  <div class="text-center flex-1">
                    <span class="text-xs text-gray-500 block">Stock</span>
                    <span class="text-sm font-medium text-gray-900"><?php echo e($produit->stock_actuel); ?></span>
                  </div>
                  <div class="text-center flex-1 border-l">
                    <span class="text-xs text-gray-500 block">Marge</span>
                    <span
                      class="text-sm font-medium text-success-600"><?php echo e(number_format($produit->marge_reelle_unite, 1)); ?>%</span>
                  </div>
                </div>
              </div>

              <!-- Actions -->
              <div class="flex space-x-2">
                <a href="<?php echo e(route('produits.show', $produit)); ?>" class="flex-1 btn-secondary text-center text-xs py-2">
                  Voir
                </a>
                <a href="<?php echo e(route('produits.edit', $produit)); ?>" class="flex-1 btn-primary text-center text-xs py-2">
                  Modifier
                </a>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <!-- Pagination -->
      <?php if($produits->hasPages()): ?>
        <div class="mt-8">
          <?php echo e($produits->appends(request()->query())->links()); ?>

        </div>
      <?php endif; ?>

    <?php else: ?>
      <div class="text-center py-12">
        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
        </svg>
        <h3 class="mt-2 text-sm font-medium text-gray-900">Aucun produit trouvé</h3>
        <p class="mt-1 text-sm text-gray-500">Commencez par ajouter votre premier produit.</p>
        <div class="mt-6">
          <a href="<?php echo e(route('produits.create')); ?>" class="btn-primary">
            <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            Nouveau Produit
          </a>
        </div>
      </div>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
  <style>
    .line-clamp-2 {
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
  </style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Gebruiker\Documents\Docs_programmation\Professionnel\Annee-2025\ets-dubai\ETS-DUBAI\resources\views/produits/index.blade.php ENDPATH**/ ?>