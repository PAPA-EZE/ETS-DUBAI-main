

<?php $__env->startSection('title', $produit->nom); ?>
<?php $__env->startSection('page-title', $produit->nom); ?>

<?php $__env->startSection('content'); ?>
  <div class="fade-in">
    <!-- Breadcrumb -->
    <nav class="flex mb-6" aria-label="Breadcrumb">
      <ol class="inline-flex items-center space-x-1 md:space-x-3">
        <li class="inline-flex items-center">
          <a href="<?php echo e(route('produits.index')); ?>" class="text-gray-700 hover:text-primary-600 transition-colors">
            <svg class="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round"
                d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
            </svg>
            Produits
          </a>
        </li>
        <li>
          <div class="flex items-center">
            <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd"
                d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                clip-rule="evenodd" />
            </svg>
            <span class="ml-1 text-gray-500"><?php echo e($produit->nom); ?></span>
          </div>
        </li>
      </ol>
    </nav>

    <!-- Header avec actions -->
    <div class="page-header">
      <div class="flex items-center">
        <div class="h-16 w-16 rounded-xl bg-gray-100 flex items-center justify-center mr-4">
          <svg class="h-8 w-8 text-gray-600" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
          </svg>
        </div>
        <div>
          <h1 class="text-2xl font-bold text-gray-900 flex items-center">
            <?php echo e($produit->nom); ?>


            <!-- Badge catégorie -->
            <span
              class="ml-3 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
              <?php echo e($produit->categorie->nom); ?>

            </span>

            <!-- Badge statut stock -->
            <?php if($produit->stock_actuel <= 0): ?>
              <span
                class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-danger-100 text-danger-800">
                <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 8 8">
                  <circle cx="4" cy="4" r="3" />
                </svg>
                Rupture
              </span>
            <?php elseif($produit->stock_actuel <= $produit->stock_minimum): ?>
              <span
                class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent-100 text-accent-800">
                <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 8 8">
                  <circle cx="4" cy="4" r="3" />
                </svg>
                Stock faible
              </span>
            <?php else: ?>
              <span
                class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success-100 text-success-800">
                <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 8 8">
                  <circle cx="4" cy="4" r="3" />
                </svg>
                En stock
              </span>
            <?php endif; ?>

            <?php if(!$produit->actif): ?>
              <span
                class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                Inactif
              </span>
            <?php endif; ?>
          </h1>
          <p class="mt-1 text-sm text-gray-600">
            Référence: <?php echo e($produit->reference); ?> •
            Fournisseur: <?php echo e($produit->fournisseur->nom); ?> •
            Type: <?php echo e($produit->libelle_conditionnement); ?>

          </p>
        </div>
      </div>
      <div class="mt-4 sm:mt-0 flex space-x-3">
        <a href="<?php echo e(route('produits.edit', $produit)); ?>" class="btn-primary">
          <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" />
          </svg>
          Modifier
        </a>
        <button type="button" onclick="confirmDelete()" class="btn-danger">
          <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
          </svg>
          Supprimer
        </button>
      </div>
    </div>

    <!-- Contenu principal -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <!-- Informations principales -->
      <div class="lg:col-span-2 space-y-6">
        <!-- Détails du produit -->
        <div class="card p-6">
          <h3 class="text-lg font-medium text-gray-900 mb-4">Détails du produit</h3>
          <dl class="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <dt class="text-sm font-medium text-gray-500">Référence</dt>
              <dd class="mt-1 text-sm text-gray-900"><?php echo e($produit->reference); ?></dd>
            </div>

            <?php if($produit->code_barre): ?>
              <div>
                <dt class="text-sm font-medium text-gray-500">Code-barres</dt>
                <dd class="mt-1 text-sm text-gray-900 font-mono"><?php echo e($produit->code_barre); ?></dd>
              </div>
            <?php endif; ?>

            <div>
              <dt class="text-sm font-medium text-gray-500">Type de conditionnement</dt>
              <dd class="mt-1 text-sm text-gray-900 capitalize"><?php echo e($produit->libelle_conditionnement); ?></dd>
            </div>

            <div>
              <dt class="text-sm font-medium text-gray-500">Unités par <?php echo e(strtolower($produit->libelle_conditionnement)); ?>

              </dt>
              <dd class="mt-1 text-sm text-gray-900"><?php echo e($produit->unites_par_conditionnement); ?>

                <?php echo e(strtolower($produit->libelle_unite)); ?>s</dd>
            </div>

            <div>
              <dt class="text-sm font-medium text-gray-500">Fournisseur</dt>
              <dd class="mt-1 text-sm">
                <a href="<?php echo e(route('fournisseurs.show', $produit->fournisseur)); ?>"
                  class="text-primary-600 hover:text-primary-800 transition-colors">
                  <?php echo e($produit->fournisseur->nom); ?>

                </a>
              </dd>
            </div>

            <?php if($produit->tva_applicable): ?>
              <div>
                <dt class="text-sm font-medium text-gray-500">TVA</dt>
                <dd class="mt-1 text-sm text-gray-900"><?php echo e(number_format($produit->taux_tva, 2)); ?>%</dd>
              </div>
            <?php endif; ?>

            <?php if($produit->description): ?>
              <div class="sm:col-span-2">
                <dt class="text-sm font-medium text-gray-500">Description</dt>
                <dd class="mt-1 text-sm text-gray-900"><?php echo e($produit->description); ?></dd>
              </div>
            <?php endif; ?>
          </dl>
        </div>

        <!-- Tarification -->
        <div class="card p-6">
          <h3 class="text-lg font-medium text-gray-900 mb-4">Tarification</h3>

          <!-- Prix par conditionnement -->
          <div class="mb-6">
            <h4 class="text-sm font-medium text-blue-900 mb-3">Prix par <?php echo e($produit->libelle_conditionnement); ?></h4>
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div class="text-center p-4 bg-blue-50 rounded-lg">
                <dt class="text-sm font-medium text-blue-600">Prix d'achat HT</dt>
                <dd class="mt-2 text-2xl font-bold text-blue-900">
                  <?php echo e(number_format($produit->prix_achat_conditionnement, 0, ',', ' ')); ?>

                  <span class="text-sm font-normal text-blue-600">FCFA</span>
                </dd>
              </div>

              <div class="text-center p-4 bg-blue-100 rounded-lg">
                <dt class="text-sm font-medium text-blue-700">Prix de vente</dt>
                <dd class="mt-2 text-2xl font-bold text-blue-900">
                  <?php echo e(number_format($produit->prix_vente_conditionnement, 0, ',', ' ')); ?>

                  <span class="text-sm font-normal text-blue-700">FCFA</span>
                </dd>
              </div>

              <div class="text-center p-4 bg-blue-200 rounded-lg">
                <dt class="text-sm font-medium text-blue-800">Marge</dt>
                <dd class="mt-2 text-2xl font-bold text-blue-900">
                  <?php echo e(number_format($produit->marge_reelle_conditionnement, 1)); ?>%
                </dd>
                <dd class="text-xs text-blue-700">
                  +<?php echo e(number_format($produit->prix_vente_conditionnement - $produit->prix_achat_conditionnement, 0, ',', ' ')); ?>

                  FCFA
                </dd>
              </div>
            </div>
          </div>

          <!-- Prix par unité -->
          <div>
            <h4 class="text-sm font-medium text-green-900 mb-3">Prix par <?php echo e($produit->libelle_unite); ?></h4>
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div class="text-center p-4 bg-green-50 rounded-lg">
                <dt class="text-sm font-medium text-green-600">Prix d'achat HT</dt>
                <dd class="mt-2 text-2xl font-bold text-green-900">
                  <?php echo e(number_format($produit->prix_achat_unite, 0, ',', ' ')); ?>

                  <span class="text-sm font-normal text-green-600">FCFA</span>
                </dd>
              </div>

              <div class="text-center p-4 bg-green-100 rounded-lg">
                <dt class="text-sm font-medium text-green-700">Prix de vente</dt>
                <dd class="mt-2 text-2xl font-bold text-green-900">
                  <?php echo e(number_format($produit->prix_vente_unite, 0, ',', ' ')); ?>

                  <span class="text-sm font-normal text-green-700">FCFA</span>
                </dd>
                <?php if($produit->tva_applicable): ?>
                  <dd class="text-xs text-green-600 mt-1">
                    TTC: <?php echo e(number_format($produit->prix_vente_unite_ttc, 0, ',', ' ')); ?> FCFA
                  </dd>
                <?php endif; ?>
              </div>

              <div class="text-center p-4 bg-green-200 rounded-lg">
                <dt class="text-sm font-medium text-green-800">Marge</dt>
                <dd class="mt-2 text-2xl font-bold text-green-900">
                  <?php echo e(number_format($produit->marge_reelle_unite, 1)); ?>%
                </dd>
                <dd class="text-xs text-green-700">
                  +<?php echo e(number_format($produit->prix_vente_unite - $produit->prix_achat_unite, 0, ',', ' ')); ?> FCFA
                </dd>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Sidebar -->
      <div class="space-y-6">
        <!-- Stock -->
        <div class="card p-6">
          <h3 class="text-lg font-medium text-gray-900 mb-4">Gestion des stocks</h3>
          <div class="space-y-4">
            <div class="text-center">
              <div class="text-4xl font-bold text-gray-900"><?php echo e($produit->stock_actuel); ?></div>
              <div class="text-sm text-gray-500"><?php echo e(strtolower($produit->libelle_unite)); ?>s en stock</div>
              <div class="text-xs text-gray-400 mt-1">
                <?php echo e($produit->afficherStock($produit->stock_actuel)); ?>

              </div>
            </div>

            <div class="space-y-2">
              <div class="flex justify-between text-sm">
                <span class="text-gray-500">Stock minimum:</span>
                <span class="font-medium"><?php echo e($produit->stock_minimum); ?></span>
              </div>
            </div>

            <!-- Barre de progression du stock -->
            <div class="mt-4">
              <div class="flex justify-between text-xs text-gray-500 mb-1">
                <span>0</span>
                <span>Stock minimum: <?php echo e($produit->stock_minimum); ?></span>
              </div>
              <div class="w-full bg-gray-200 rounded-full h-2">
                <?php
                  $percentage = $produit->stock_minimum > 0 ? ($produit->stock_actuel / ($produit->stock_minimum * 2)) * 100 : 100;
                  $color = $produit->stock_actuel <= 0 ? 'bg-danger-500' :
                    ($produit->stock_actuel <= $produit->stock_minimum ? 'bg-accent-500' : 'bg-success-500');
                ?>
                <div class="<?php echo e($color); ?> h-2 rounded-full transition-all duration-300"
                  style="width: <?php echo e(min($percentage, 100)); ?>%"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Actions rapides -->
        <div class="card p-6">
          <h3 class="text-lg font-medium text-gray-900 mb-4">Actions rapides</h3>
          <div class="space-y-3">
            <a href="#" class="btn-primary w-full">
              <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round"
                  d="M7.5 21L3 16.5m0 0L7.5 12M3 16.5h13.5m0-13.5L21 7.5m0 0L16.5 12M21 7.5H7.5" />
              </svg>
              Transférer du stock
            </a>
            <a href="#" class="btn-secondary w-full">
              <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round"
                  d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
              </svg>
              Historique des mouvements
            </a>
          </div>
        </div>

        <!-- Informations système -->
        <div class="card p-6">
          <h3 class="text-lg font-medium text-gray-900 mb-4">Informations</h3>
          <dl class="space-y-3 text-sm">
            <div>
              <dt class="text-gray-500">Créé le</dt>
              <dd class="font-medium"><?php echo e($produit->created_at->format('d/m/Y à H:i')); ?></dd>
            </div>
            <div>
              <dt class="text-gray-500">Modifié le</dt>
              <dd class="font-medium"><?php echo e($produit->updated_at->format('d/m/Y à H:i')); ?></dd>
            </div>
          </dl>
        </div>
      </div>
    </div>

    <!-- Formulaire de suppression caché -->
    <form id="deleteForm" method="POST" action="<?php echo e(route('produits.destroy', $produit)); ?>" class="hidden">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script>
    function confirmDelete() {
      if (confirm('Êtes-vous sûr de vouloir supprimer ce produit ? Cette action est irréversible.')) {
        document.getElementById('deleteForm').submit();
      }
    }
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Gebruiker\Documents\Docs_programmation\Professionnel\Annee-2025\ets-dubai\ETS-DUBAI\resources\views/produits/show.blade.php ENDPATH**/ ?>