<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserIsAdmin
{
  /**
   * Vérifier que l'utilisateur est un administrateur
   */
  public function handle(Request $request, Closure $next): Response
  {
    if (!auth()->check()) {
      return redirect()->route('login');
    }

    if (auth()->user()->role !== 'admin') {
      abort(403, 'Accès refusé. Cette fonctionnalité est réservée aux administrateurs.');
    }

    return $next($request);
  }
}
