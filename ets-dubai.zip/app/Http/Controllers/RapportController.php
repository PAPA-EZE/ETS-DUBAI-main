<?php

namespace App\Http\Controllers;

use App\Models\Vente;
use App\Models\Produit;
use App\Models\Client;
use App\Models\Fournisseur;
use App\Models\Commande;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Barryvdh\DomPDF\Facade\Pdf;

class RapportController extends Controller
{
    /**
     * Page principale des rapports
     */
    public function index()
    {
        return view('rapports.index');
    }

    /**
     * Rapport des ventes
     */
    public function ventes(Request $request)
    {
        $validated = $request->validate([
            'date_debut' => 'required|date',
            'date_fin' => 'required|date|after_or_equal:date_debut',
            'format' => 'nullable|in:pdf,excel',
        ]);

        $dateDebut = Carbon::parse($validated['date_debut']);
        $dateFin = Carbon::parse($validated['date_fin']);

        // Récupérer les données
        $ventes = Vente::with(['client', 'vendeur', 'items.produit'])
            ->where('statut', 'validee')
            ->whereBetween('date_vente', [$dateDebut, $dateFin])
            ->orderBy('date_vente', 'desc')
            ->get();

        // Statistiques globales
        $stats = [
            'nombre_ventes' => $ventes->count(),
            'ca_total' => $ventes->sum('montant_total'),
            'ca_moyen' => $ventes->avg('montant_total'),
            'articles_vendus' => $ventes->sum(fn($v) => $v->items->sum('quantite')),

            // Par type de paiement
            'especes' => $ventes->where('type_paiement', 'especes')->sum('montant_total'),
            'mobile_money' => $ventes->where('type_paiement', 'mobile_money')->sum('montant_total'),
            'credit' => $ventes->where('type_paiement', 'credit')->sum('montant_total'),

            // Par vendeur
            'par_vendeur' => $ventes->groupBy('user_id')->map(function ($groupe) {
                return [
                    'vendeur' => $groupe->first()->vendeur->name,
                    'nombre' => $groupe->count(),
                    'montant' => $groupe->sum('montant_total'),
                ];
            }),
        ];

        // Top produits
        $topProduits = DB::table('vente_items')
            ->join('ventes', 'vente_items.vente_id', '=', 'ventes.id')
            ->join('produits', 'vente_items.produit_id', '=', 'produits.id')
            ->whereBetween('ventes.date_vente', [$dateDebut, $dateFin])
            ->where('ventes.statut', 'validee')
            ->select(
                'produits.nom',
                DB::raw('SUM(vente_items.quantite) as total_quantite'),
                DB::raw('SUM(vente_items.montant_ligne_ttc) as total_ca')
            )
            ->groupBy('produits.id', 'produits.nom')
            ->orderBy('total_ca', 'desc')
            ->limit(10)
            ->get();

        // Top clients
        $topClients = DB::table('ventes')
            ->leftJoin('clients', 'ventes.client_id', '=', 'clients.id')
            ->whereBetween('ventes.date_vente', [$dateDebut, $dateFin])
            ->where('ventes.statut', 'validee')
            ->whereNotNull('ventes.client_id')
            ->select(
                'clients.nom',
                DB::raw('COUNT(*) as nombre_achats'),
                DB::raw('SUM(ventes.montant_total) as total_ca')
            )
            ->groupBy('clients.id', 'clients.nom')
            ->orderBy('total_ca', 'desc')
            ->limit(10)
            ->get();

        // Évolution journalière
        $evolutionJournaliere = DB::table('ventes')
            ->whereBetween('date_vente', [$dateDebut, $dateFin])
            ->where('statut', 'validee')
            ->select(
                DB::raw('DATE(date_vente) as date'),
                DB::raw('COUNT(*) as nombre'),
                DB::raw('SUM(montant_total) as ca')
            )
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $data = compact('dateDebut', 'dateFin', 'ventes', 'stats', 'topProduits', 'topClients', 'evolutionJournaliere');

        // Générer selon le format demandé
        if ($request->filled('format')) {
            return $this->exporterVentes($data, $validated['format']);
        }

        return view('rapports.ventes', $data);
    }

    /**
     * Rapport des stocks
     */
    public function stocks()
    {
        $produits = Produit::with(['categorie', 'fournisseur'])
            ->actif()
            ->orderBy('stock_actuel')
            ->get();

        // Statistiques
        $stats = [
            'total_produits' => $produits->count(),
            'en_rupture' => $produits->where('stock_actuel', '<=', 0)->count(),
            'stock_faible' => $produits->where('stock_actuel', '>', 0)
                ->where('stock_actuel', '<=', DB::raw('stock_minimum'))
                ->count(),
            'valeur_stock' => $produits->sum(fn($p) => $p->stock_actuel * $p->prix_achat),
        ];

        // Par catégorie
        $parCategorie = $produits->groupBy('categorie.nom')->map(function ($groupe) {
            return [
                'nombre' => $groupe->count(),
                'quantite_totale' => $groupe->sum('stock_actuel'),
                'valeur' => $groupe->sum(fn($p) => $p->stock_actuel * $p->prix_achat),
            ];
        });

        return view('rapports.stocks', compact('produits', 'stats', 'parCategorie'));
    }

    /**
     * Rapport des achats (commandes fournisseurs)
     */
    public function achats(Request $request)
    {
        $validated = $request->validate([
            'date_debut' => 'required|date',
            'date_fin' => 'required|date|after_or_equal:date_debut',
        ]);

        $dateDebut = Carbon::parse($validated['date_debut']);
        $dateFin = Carbon::parse($validated['date_fin']);

        // Commandes de la période
        $commandes = Commande::with(['fournisseur', 'items.produit'])
            ->whereIn('statut', ['livree', 'partiellement_livree'])
            ->whereBetween('date_livraison_reelle', [$dateDebut, $dateFin])
            ->orderBy('date_livraison_reelle', 'desc')
            ->get();

        // Stats
        $stats = [
            'nombre_commandes' => $commandes->count(),
            'montant_total_ht' => $commandes->sum('montant_ht'),
            'montant_total_ttc' => $commandes->sum('montant_ttc'),
            'ristournes_prevues' => $commandes->sum('ristourne_prevue'),
        ];

        // Par fournisseur
        $parFournisseur = $commandes->groupBy('fournisseur.nom')->map(function ($groupe) {
            return [
                'nombre' => $groupe->count(),
                'montant_ht' => $groupe->sum('montant_ht'),
                'ristourne' => $groupe->sum('ristourne_prevue'),
            ];
        });

        return view('rapports.achats', compact('dateDebut', 'dateFin', 'commandes', 'stats', 'parFournisseur'));
    }

    /**
     * Tableau de bord financier
     */
    public function financier(Request $request)
    {
        $mois = $request->get('mois', now()->month);
        $annee = $request->get('annee', now()->year);

        $debut = Carbon::create($annee, $mois, 1)->startOfMonth();
        $fin = $debut->copy()->endOfMonth();

        // Chiffre d'affaires
        $caVentes = Vente::where('statut', 'validee')
            ->whereBetween('date_vente', [$debut, $fin])
            ->sum('montant_total');

        // Achats
        $montantAchats = Commande::whereIn('statut', ['livree', 'partiellement_livree'])
            ->whereBetween('date_livraison_reelle', [$debut, $fin])
            ->sum('montant_ttc');

        // Marge brute
        $margeBrute = $caVentes - $montantAchats;
        $tauxMarge = $caVentes > 0 ? ($margeBrute / $caVentes) * 100 : 0;

        // Crédit clients
        $creditUtilise = Client::sum('solde_actuel');
        $creditDisponible = Client::sum('credit_limite') - $creditUtilise;

        $stats = compact('caVentes', 'montantAchats', 'margeBrute', 'tauxMarge', 'creditUtilise', 'creditDisponible');

        // Évolution mensuelle (12 derniers mois)
        $evolutionMensuelle = [];
        for ($i = 11; $i >= 0; $i--) {
            $moisDebut = now()->subMonths($i)->startOfMonth();
            $moisFin = $moisDebut->copy()->endOfMonth();

            $evolutionMensuelle[] = [
                'mois' => $moisDebut->format('M Y'),
                'ventes' => Vente::where('statut', 'validee')
                    ->whereBetween('date_vente', [$moisDebut, $moisFin])
                    ->sum('montant_total'),
                'achats' => Commande::whereIn('statut', ['livree', 'partiellement_livree'])
                    ->whereBetween('date_livraison_reelle', [$moisDebut, $moisFin])
                    ->sum('montant_ttc'),
            ];
        }

        return view('rapports.financier', compact('debut', 'fin', 'stats', 'evolutionMensuelle'));
    }

    /**
     * Exporter rapport ventes
     */
    private function exporterVentes($data, $format)
    {
        if ($format === 'pdf') {
            $pdf = Pdf::loadView('rapports.exports.ventes-pdf', $data);
            return $pdf->download('rapport-ventes-' . now()->format('Y-m-d') . '.pdf');
        }

        // TODO: Implémenter export Excel si nécessaire
        return back()->with('info', 'Export Excel à venir');
    }
}
